Python 3.12.2 (tags/v3.12.2:6abddd9, Feb  6 2024, 21:26:36) [MSC v.1937 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

= RESTART: C:/Users/dell/Desktop/nagalakshmi/indhu.py
Enter the number of patients: 2
Enter patient name: indhu
Enter gender: female
Enter age: 20
Enter heart rate: 100
Enter blood pressure: 120
Enter sugar level: 130
Enter patient name: rk
Enter gender: male
Enter age: 23
Enter heart rate: 100
Enter blood pressure: 120
Enter sugar level: 130
indhu
rk
patient_name	gender	age	heart_rate	blood_pressure	sugar_levels
indhu		female	20	100		120		130
rk		male	23	100		120		130
  patient_name  gender  age  heart_rate  blood_pressure  sugar_level
0        indhu  female   20         100             120          130
1           rk    male   23         100             120          130
{1}
{1}
[{'patient_name': 'indhu', 'gender': 'female', 'age': 20, 'heart_rate': 100, 'blood_pressure': 120, 'sugar_level': 130}, {'patient_name': 'rk', 'gender': 'male', 'age': 23, 'heart_rate': 100, 'blood_pressure': 120, 'sugar_level': 130}]
100
100
120
120
130
130
23
20
